#!/bin/bash

# Script de backup diario - Origen y destino fijos

ORIGEN="/www_dir"
DESTINO="/backup_dir"

# Validar existencia de origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen ($ORIGEN) no existe o no es un directorio."
    exit 2
fi

# Validar existencia del destino
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino ($DESTINO) no existe."
    exit 3
fi

# Fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)

# Nombre base del directorio
BASE_ORIGEN=$(basename "$ORIGEN")

# Nombre del archivo con guiones bajos como pide el enunciado
ARCHIVO_BKP="${BASE_ORIGEN}_bkp_${FECHA}.tar.gz"

# Ejecutar el backup
tar -czf "${DESTINO}/${ARCHIVO_BKP}" -C "$(dirname "$ORIGEN")" "$BASE_ORIGEN"

# Verificar resultado
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: ${DESTINO}/${ARCHIVO_BKP}"
else
    echo "Error al realizar el backup."
    exit 4
fi

