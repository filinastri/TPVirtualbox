#!/bin/bash

usage() {
  echo "Uso: $0 -o <origen> -d <destino>"
  echo "Opciones:"
  echo "  -o    Directorio origen a respaldar"
  echo "  -d    Directorio destino donde se guardará el backup"
  echo "  -help Mostrar esta ayuda"
  exit 1
}

if [[ $# -eq 0 || "$1" == "-help" ]]; then
  usage
fi

while getopts "o:d:" opt; do
  case $opt in
    o) ORIGEN="$OPTARG" ;;
    d) DESTINO="$OPTARG" ;;
    *) usage ;;
  esac
done

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
  echo "Error: Debe especificar origen y destino."
  usage
fi

# Validar que origen exista y sea un directorio accesible
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio origen ($ORIGEN) no existe o no es un directorio."
  exit 2
fi

# Validar que destino esté montado (para asegurarnos que está en la partición correcta)
if ! mountpoint -q "$DESTINO"; then
  echo "Error: El directorio destino ($DESTINO) no está montado o no existe."
  exit 3
fi

FECHA=$(date +%Y%m%d)
BASE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO_BKP="${BASE_ORIGEN}_bkp_${FECHA}.tar.gz"

tar -czf "${DESTINO}/${ARCHIVO_BKP}" -C "$(dirname "$ORIGEN")" "$BASE_ORIGEN"

if [[ $? -eq 0 ]]; then
  echo "Backup exitoso: ${DESTINO}/${ARCHIVO_BKP}"
else
  echo "Error al realizar el backup."
  exit 4
fi

